#testdir <- file.path(library(help="EIEvent")$path,"testScripts")
testdir <- "/home/ralmond/Projects/EIEvent/inst/testScripts"


testRuleScript(file.path(testdir,"Agents-bug64.json"))
