library(EABN)
eviddb <- mongo("EvidenceSets","EARecords","mongodb://localhost")

#ev1 <- getOneRec('{}',eviddb,parseEvidence)

evidSetlin <- getManyRecs('{"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/Sp2019/linear"}',
                       eviddb,parseEvidence)
evidSetadp <- getManyRecs('{"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/Sp2019/adaptive"}',
                       eviddb,parseEvidence)
evidSetusr <- getManyRecs('{"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/Sp2019/userControl"}',
                       eviddb,parseEvidence)
pathstem <- "ecd://epls.coe.fsu.edu/PhysicsPlayground/Sp2019"

result <- list("linear"=NULL,"adaptive"=NULL,"userControl"=NULL)

for (cond in names(result)) {
    evidSet <-getManyRecs(sprintf('{"app":"%s"}',file.path(pathstem,cond)),
                          eviddb,parseEvidence)

    allfields <- sapply(evidSet, function (s) names(details(s)))
    ufields <- unique(do.call(c,allfields))
    nfields <- c("uid","context","timestamp","app",ufields[ufields!="trophyHall"])

    N <- length(evidSet)
    obsDF <- lapply(nfields, function(n) rep(NA,N))
    names(obsDF) <- nfields
    obsDF <- as.data.frame(obsDF)
    obsDF$timestamp <- rep(NA,N)

    for (n in 1:N) {
        obsDF[n,"uid"] <- uid(evidSet[[n]])
        obsDF[n,"context"] <- context(evidSet[[n]])
        obsDF[n,"timestamp"] <- toString(timestamp(evidSet[[n]]))
        obsDF[n,"app"] <- basename(app(evidSet[[n]]))
        obs <- details(evidSet[[n]])
        for (oname in names(obs)) {
            if (oname %in% names(obsDF)) {
                val <- obs[[oname]]
                if (oname=="agentsUsed")
                    val <- paste(val,collapse=", ")
                if (length(val) > 0L)
                    obsDF[n,oname] <- val
            }
        }
    }
    write.csv(obsDF,sprintf("Obs%s-2019-05-10.csv",cond))
    result[[cond]] <- obsDF
}
              
