#!/bin/bash
mongoimport -d EIRecords -c Events --jsonArray
