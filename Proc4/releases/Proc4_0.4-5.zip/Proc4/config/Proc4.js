var apps = [
    {"app":"ecd://epls.coe.fsu.edu/P4test","doc":"Testing","active":true},
    {"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/userControl",
     "doc":"User Controled (Spring 2019)","active":true},
    {"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/linear",
     "doc":"linear (Spring 2019)","active":true},
    {"app":"ecd://epls.coe.fsu.edu/PhysicsPlayground/adaptive",
     "doc":"adaptive (Spring 2019)","active":true}
    ];
var pwds = [
    {"user":"EAP","pwd":"secret"},
    {"user":"ASP","pwd":"secret"},
    {"user":"EIP","pwd":"secret"},
    {"user":"C4","pwd":"secret"}
];
