// Make up passwords and edit them here.
// Then save this file in your home directory as ".Proc4.js"
// (or wherever else you want.)

var pwds = [
    {"user":"EAP","pwd":"Secret1"},
    {"user":"ASP","pwd":"Secret2"},
    {"user":"EIP","pwd":"Secret3"},
    {"user":"C4","pwd":"Secret4"}
];
